#define CONFIG_BUSYBOX_EXEC_PATH "/proc/self/exe"
